<?php

$_LANG['HAVENOT_OPEN_ETAO'] = '后台尚未开启通一淘';
$_LANG['ETAO_ACCOUNT_CANNT_EMPTY'] = '一淘商户帐号不能为空';
$_LANG['ITEM_NOT_EXIST'] = '商品不存在';

