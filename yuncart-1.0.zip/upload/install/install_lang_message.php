<?php


$_LANG['PHP_VERSION_OLDER']				= 'php版本低';
$_LANG['FILE_UPLOAD_UNSUPPORT']			= 'php未开启文件上传';
$_LANG['PHP_EXTENTION_UNLOAD_MYSQL']	= 'php未开启mysql扩展';
$_LANG['PHP_EXTENTION_UNLOAD_GD']		= 'php未开启gd扩展';
$_LANG['PHP_EXTENTION_UNLOAD_MBSTRING'] = 'php未开启mbstring扩展';
$_LANG['PHP_EXTENTION_UNLOAD_PDO']		= 'php未开启pdo扩展';
$_LANG['PHP_EXTENTION_UNLOAD_PDOMYSQL']	= 'php未开启pdo_mysql扩展';
$_LANG['MYSQL_UNSUPPORT']				= '不支持MYSQL数据库';
$_LANG['MYSQL_VERSION_OLDER']			= 'mysql版本低';

$_LANG['DATA_DIR_NOT_WRITABLE']			= 'data目录不可写';
$_LANG['UPLOADS_DIR_NOT_WRITABLE']		= 'uploads目录不可写';
$_LANG['ROOT_NOT_WRITABLE']				= '根目录文件不可写';

$_LANG['CANNT_CREATE_DATABASE']			= '不能创建数据库';
$_LANG['CANNT_CONNECT_MYSQL_HOST']		= '不能连接到mysql服务器';
$_LANG['IMPORT_SQLFILE_ERROR']			= '创建表数据出错';
$_LANG['CREATE_CONFIGFILE_ERROR']		= 'config.inc.php生成出错';
$_LANG['ADD_ADMIN_ERROR']				= '新建管理员出错';
$_LANG['ADD_DBCONFIG_ERROR']			= '插入表config，或修改管理文件名出错';
$_LANG['TOUCH_LOCK_ERROR']				= '生成data目录lock文件出错';
$_LANG['LOCK_EXIST']					= 'lock文件存在，如需重新安装，请首先删除！';
$_LANG['INSTALL_TEST_ERROR']			= '安装体验数据出错';

$_LANG['ACCESS_ERROR']					= '访问错误';





