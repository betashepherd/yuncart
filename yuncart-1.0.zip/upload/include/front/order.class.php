<?php

defined('IN_CART') or die;

class Order extends Base{
	
}