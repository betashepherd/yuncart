<?php
$spname="陈湘";
$partner = "1215067401";                                  	//财付通商户号
$key = "06bdc1d85dfd973a62f92df82b512ff2";											//财付通密钥

$return_url = "http://upload.yuncart.com/payReturnUrl.php";			//显示支付结果页面,*替换成payReturnUrl.php所在路径
$notify_url = "http://upload.yuncart.com/payNotifyUrl.php";			//支付完成后的回调处理页面,*替换成payNotifyUrl.php所在路径
?>