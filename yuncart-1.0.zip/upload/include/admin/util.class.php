<?php

defined('IN_CART') or die;

/**
 *
 * 后台操作公用 
 *
 */
class Util extends Base{
	
	
}